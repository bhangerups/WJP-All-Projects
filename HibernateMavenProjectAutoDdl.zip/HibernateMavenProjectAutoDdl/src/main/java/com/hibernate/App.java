package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.bean.Staff;
import com.hibernate.bean.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//Student stud1= new Student(101,"Rupali Bhange","rupalibhange98@gmail.com");
    	//Student stud2= new Student(102,"Sneha Kadam","sneha@gmail.com");
    	Staff staff1=new Staff(103,"Ram Chavan","ram@gmail.com");
    	
        Configuration cfg=new Configuration();
        cfg.configure("resources/hibernate.cfg.xml");
        
        SessionFactory sf=cfg.buildSessionFactory();
        System.out.println("tables created.....");
        
        Session session=sf.openSession();
        //session.save(stud1);
        //session.save(stud2);
        session.save(staff1);
        session.beginTransaction().commit();
        System.out.println("Data Inserted Successfully...");
        
        session.close();
        sf.close();
        
    }
}
