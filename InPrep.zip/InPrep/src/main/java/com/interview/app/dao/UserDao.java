package com.interview.app.dao;

import com.interview.app.entity.Users;

public interface UserDao {
	
	public void insert(Users users);
	public void selectByUsernameAndPassword(Users user);

}
