package com.interview.app.dao;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.interview.app.entity.Users;
import com.interview.app.utility.FactoryProvider;

public class UserDaoImpl implements UserDao {

	public void insert(Users users) {
		Session session=FactoryProvider.getFactory().openSession();
		session.save(users);
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		
		session.close();
		FactoryProvider.closeFactory();
	}

	public void selectByUsernameAndPassword(Users user) {
		Session session=FactoryProvider.getFactory().openSession();
		Query query=session.createQuery("from Users u where u.email=:email and u.password=:password");
		query.setParameter("email", user.getEmail());
        query.setParameter("password", user.getPassword());
        //query.setParameter("name",user.getName());
        
        List result = query.list();
       

        System.out.println("resultset:"+result);

        Iterator iterator = result.iterator();
        while(iterator.hasNext()){
            Users user1= (Users) iterator.next();

		}
        
        session.close();
        FactoryProvider.closeFactory();

	}
		
	}


