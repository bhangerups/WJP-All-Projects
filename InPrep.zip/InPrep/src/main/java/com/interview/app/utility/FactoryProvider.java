package com.interview.app.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.interview.app.entity.Users;

public class FactoryProvider {
	private static SessionFactory sessionFactory;
	public static SessionFactory getFactory() {
		
		if(sessionFactory==null) {
			
			sessionFactory =new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			
		}
		
		return sessionFactory;
		
		
	}
	
	public static void closeFactory() {
		if(sessionFactory.isOpen()) {
			sessionFactory.close();
		}
	}
	public static void main(String[] args) {
		
		Users user= new Users();
		user.setName("Rupali");
		user.setEmail("rupalibhange98@gmail.com");
		user.setPassword("rupali");
		user.setRole("Admin");
		
		Session session=getFactory().openSession();
		session.save(user);
		session.beginTransaction().commit();
		
		session.close();
		closeFactory();
	}
	

}
